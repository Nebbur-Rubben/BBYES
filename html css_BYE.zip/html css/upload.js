//上传  

//源码
        this.upload = function (url, pdata, callback) {
            var fd = new FormData();  
            fd.append('file', this.getBlob());  

            var xhr = new XMLHttpRequest();
            for (var e in pdata)
            fd.append(e, pdata[e]);  
            if (callback) {  
                xhr.upload.addEventListener('progress', function (e) {  
                    callback('uploading', e);  
                }, false);  
                xhr.addEventListener('load', function (e) {  
                    callback('ok', e);  
                }, false);  
                xhr.addEventListener('error', function (e) {  
                    callback('error', e);  
                }, false);  
                xhr.addEventListener('abort', function (e) {  
                    callback('cancel', e);  
                }, false);  
            }  
            xhr.open('POST', url);  
            xhr.send(fd);  
        };

//上传到服务器
        this.upload = function (url, pdata, callback) {
            var fd = new FormData();
            fd.append('audio', this.getBlob(), 'audio.wav'); // 添加.wav文件的二进制数据
          
            var xhr = new XMLHttpRequest();
            for (var e in pdata)
              fd.append(e, pdata[e]);
          
            if (callback) {
              xhr.upload.addEventListener('progress', function (e) {
                callback('uploading', e);
              }, false);
              xhr.addEventListener('load', function (e) {
                callback('ok', e);
              }, false);
              xhr.addEventListener('error', function (e) {
                callback('error', e);
              }, false);
              xhr.addEventListener('abort', function (e) {
                callback('cancel', e);
              }, false);
            }
          
            xhr.open('POST', url);
            xhr.setRequestHeader('Content-Type', 'audio/wav'); // 设置Content-Type为audio/wav
            xhr.send(fd);
          };

//保存到本地

this.upload = function (url, pdata, callback) {
    var fd = new FormData();
    fd.append('audio', this.getBlob(), 'audio.wav');
  
    var xhr = new XMLHttpRequest();
    for (var e in pdata)
      fd.append(e, pdata[e]);
  
    if (callback) {
      xhr.upload.addEventListener('progress', function (e) {
        callback('uploading', e);
      }, false);
      xhr.addEventListener('load', function (e) {
        // 文件上传完成后，保存文件到本地
        var reader = new FileReader();
        reader.onload = function(event) {
          var data = event.target.result;
          var blob = new Blob([data], { type: 'audio/wav' });
          var url = URL.createObjectURL(blob);
          var a = document.createElement('a');
          a.href = url;
          a.download = 'audio.wav';
          a.click();
        };
        reader.readAsArrayBuffer(xhr.response);
  
        callback('ok', e);
      }, false);
      xhr.addEventListener('error', function (e) {
        callback('error', e);
      }, false);
      xhr.addEventListener('abort', function (e) {
        callback('cancel', e);
      }, false);
    }
  
    xhr.responseType = 'arraybuffer'; // 设置响应类型为arraybuffer
    xhr.open('POST', url);
    xhr.setRequestHeader('Content-Type', 'audio/wav');
    xhr.send(fd);
  };

  //本地指定文件夹
  this.upload = function (url, pdata, callback) {
    var fd = new FormData();
    fd.append('audio', this.getBlob(), 'audio.wav');
  
    var xhr = new XMLHttpRequest();
    for (var e in pdata)
      fd.append(e, pdata[e]);
  
    if (callback) {
      xhr.upload.addEventListener('progress', function (e) {
        callback('uploading', e);
      }, false);
      xhr.addEventListener('load', function (e) {
        // 文件上传完成后，保存文件到指定文件夹
        window.requestFileSystem = window.requestFileSystem || window.webkitRequestFileSystem;
        window.requestFileSystem(window.TEMPORARY, 5 * 1024 * 1024, function(fs) {
          fs.root.getFile('/path/to/folder/audio.wav', { create: true }, function(fileEntry) {
            fileEntry.createWriter(function(fileWriter) {
              fileWriter.write(new Blob([xhr.response], { type: 'audio/wav' }));
              callback('ok', e);
            });
          });
        });
  
      }, false);
      xhr.addEventListener('error', function (e) {
        callback('error', e);
      }, false);
      xhr.addEventListener('abort', function (e) {
        callback('cancel', e);
      }, false);
    }
  
    xhr.responseType = 'arraybuffer'; // 设置响应类型为arraybuffer
    xhr.open('POST', url);
    xhr.setRequestHeader('Content-Type', 'audio/wav');
    xhr.send(fd);
  };